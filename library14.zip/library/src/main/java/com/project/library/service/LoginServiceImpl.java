package com.project.library.service;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;

import com.project.library.dao.LoginDAO;
import com.project.library.vo.MemberVO;

@Service //현재 클래스를 스프링에 관리하는 service bean으로 등록
public class LoginServiceImpl implements LoginService {
	
	
	//MemberDAO memberDao; dao 접근해서 주입
	@Inject
	private LoginDAO loginDao;
	
	//01_01. 회원 로그인 체크
	@Override
	public boolean loginCheck(MemberVO vo, HttpSession session) {
		boolean result = loginDao.loginCheck(vo);
		if(result) {	//true일 경우 세션 등록
			MemberVO vo2 = viewMember(vo); //id, pw 같은 모든 필드 값을 vo2에 설정
//			System.out.println("userId  : " +  vo2.getUserId());
//			System.out.println("userName  : " +  vo2.getUserName());
			System.out.println("userName  : " +  vo2.getUserEmail());
			//세션 변수 등록
			session.setAttribute("userId", vo2.getUserId() ); //DB에서 조회한 값(getUserId())을 userId에 넣어줌
			session.setAttribute("userName", vo2.getUserName() );
			session.setAttribute("userEmail", vo2.getUserEmail() );
		}
		return result;
	}
	
	//01_02. 회원 로그인 정보
	@Override
	public MemberVO viewMember(MemberVO vo) { 
		return loginDao.viewMember(vo);
	}

	//02. 회원 로그 아웃
	@Override
	public void logout(HttpSession session) {
		// 세션 변수 개별 삭제
		// session.removeAttribute("userId");
		// 세션 정보를 초기화 시킴
		session.invalidate(); // 또는 remove..?? 사용하거나,invalidate() 사용 ==> 세션 강제 종료
	}

}
