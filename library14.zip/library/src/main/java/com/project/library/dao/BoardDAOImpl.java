package com.project.library.dao;

import java.util.HashMap;



import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.project.library.vo.BoardVO;
import com.project.library.vo.Pageboard;



@Repository // 빈등록
public class BoardDAOImpl implements BoardDAO {

	@Inject // 주입
	private SqlSession sqlSession;

	@Override //삽입
	public void create(BoardVO vo) throws Exception {
		sqlSession.insert("board.insert", vo);
	}

	@Override  //상세보기
	public BoardVO read(int bno) throws Exception {
		return sqlSession.selectOne("board.view", bno);
	}
	

	@Override  //수정
	public void update(BoardVO vo) throws Exception {
		sqlSession.update("board.updateArticle", vo);

	}

	@Override  //삭제
	public void delete(int bno) throws Exception {
		sqlSession.delete("board.deleteArticle", bno);
	}

	@Override  //전체목록 +페이징
	// public List<BoardVO> listAll() throws Exception {
	// return sqlSession.selectList("board.listAll");
	// }

	public List<BoardVO> listAll(String searchOption, String keyword, int displayPost, int postNum) throws Exception {
		// 검색 옵션, 키워드 -> 맵에 저장
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("searchOption", searchOption);
		map.put("keyword", keyword);
		
		map.put("displayPost",displayPost);
		map.put("postNum",postNum);
		
		return sqlSession.selectList("board.listAll", map);
	}
	
	
	@Override // 조회수 증가
	public void increaseViewcnt(int bno) throws Exception {
		sqlSession.update("board.increaseViewcnt", bno);

	}
	


    //
	public int countArticle(String searchOption, String keyword) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		map.put("searchOption", searchOption);
		map.put("keyword", keyword);
		return sqlSession.selectOne("board.countArticle", map);
	}

}
